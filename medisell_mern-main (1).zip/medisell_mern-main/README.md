# medi_sell

# Project Initial Report

## Amit Gupta & 12112447

### Project Name: MediSell

# API (HTTP request) DOCUMENTATION 
 https://documenter.getpostman.com/view/32332388/2s9YymFjRm
# Figma PROTOTYPE
 - https://www.figma.com/file/gRWRdXCtDY4HhZ7VPHSpJK/Untitled?type=design&node-id=0%3A1&mode=design&t=Z2wG9VhEjHzW8nV4-1
# Deploy Link
  - https://medi-sell.netlify.app

# video
[![Watch the video](https://drive.google.com/file/d/1k6cGAT9WNQ6wiubsbKXYdSIPc0Eotbf8/view?usp=sharing)](https://drive.google.com/file/d/1k6cGAT9WNQ6wiubsbKXYdSIPc0Eotbf8/view?usp=sharing)

 ## Which problem Project is Solving?
  - Business-to-business deals
  - Logistics issues 
  - Establishing a connection between Distributor and retailer through Video conferencing 
  - Billing 
  - Common Platform for all pharmaceutical company to pitch their product with Authorised retailer 


## Similar Website
  - Udaan
  - IndiaMart
  - Alibaba
  

## How do you want to solve it?

   - Creating different sections for Company and retailer
   - Direct video conferencing between client and dealer 
   - bringing all retailer under one platfrom which will ease for campany to pitch their product 
   - Sponsored product feature enable new company to grow fast by reaching to larger market
  
## List of features you want to implement.

    - Price Calculator 
    - Offers section
    - E-billing 
    - Video calling
    - filter on bases of company 
    - search bar
   
